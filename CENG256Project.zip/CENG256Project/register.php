<!DOCTYPE HTML>
<html>
<head>
<title>Contacts</title>
<style>
 .error {color:#FF0000;}
</style>
</head>
<body>
<h2>Contact</h2>
<?php
	//define variables and set to empty values
	 $nameErr = $emailErr = $genderErr = $websiteErr = "";
	 $name = $email = $gender = $comment = $website = "";

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		 if (empty($_POST["name"])) {
			$nameErr = "Name is required";
		  } else {
			$name = test_input($_POST["name"]);  
			
		  }

		 if (empty($_POST["uname"])) {
			$unameErr = "Name is required";
		  } else {
			$uname = test_input($_POST["uname"]);  
		  }

		  if (empty($_POST["password"])) {
			$passErr = "Password is required";
		  } else {
			$password = test_input($_POST["password"]); 
		  }


		 if (empty($_POST["gender"])) {
			$genderErr = "Gender is required";
		 }else {
			$gender = test_input($_POST["gender"]); 
		}

		//continues to target page if all validation is passed
		if ( $unameErr ==""&& $passErr ==""&& $genderErr ==""&& $nameErr == ""){
			// check if exists in database
			$dbc=mysqli_connect('localhost','testuser','password','loginexample')
			or die("Could not Connect!\n");
			$sql="SELECT * from profiles WHERE username ='$uname';";
			$result =mysqli_Query($dbc,$sql) or die (" Error querying database");
			$a=mysqli_num_rows($result);

			if ($a>0){
				$unameErr="Username already exists".$a;
			}else{ // username does not exist so add to db
				$hashpass=hash('sha256',$password);
				$sql="INSERT INTO profiles VALUES(NULL,'$name','$uname','$gender','$hashpass');";
				$result =mysqli_Query($dbc,$sql) or die (" Error querying database");
				mysqli_close();
				header('Location: /login/login.php');
			}
		}
	}

       // clears spaces etc to prep data for testing
	function test_input($data){
		$data=trim ($data); // gets rid of extra spaces befor and after
		$data=stripslashes($data); //gets rid of any slashes
		$data=htmlspecialchars($data); //converts any symbols usch as < and > to special characters
		return $data;
	}

?>
<h2> PHP form Validation example </h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	Name: <input type="text" name="name" value="<?php echo $name;?>"/>
	<span class="error">* <?php echo $nameErr;?></span>
	<br/><br/>
	User Name: <input type="text" name="uname" value="<?php echo $uname;?>"/>
	<span class="error">* <?php echo $unameErr;?></span>
	<br/><br/>
	Password:
	<input type="text" name="password" value=""/>
	<span class="error">* <?php echo $passErr;?></span>
	<br/><br/>

	<input type="radio" name="gender" value="female"<?php if (isset($gender)&&$gender=="female") echo "checked"?>/>Female
	<input type="radio" name="gender" value="male" <?php if (isset($gender)&&$gender=="male") echo "checked"?>/>Male
	<span class="error">* <?php echo $genderErr;?></span>
	<br/><br/>
	<input type="submit" name="submit" value="Submit"/> 
</form>
<?php
echo "<h2> Your Input </h2>";
echo $name."<br/>";
echo $uname."<br/>";
echo $password."<br/>";
echo $gender."<br/>";
?>
</body>
</html>
